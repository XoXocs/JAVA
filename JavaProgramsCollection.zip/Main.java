public class Main {
    public static void main(String[] args) {
        TrafficSignal signal = new TrafficSignal();
        signal.startSimulation(3, 3);
    }
}